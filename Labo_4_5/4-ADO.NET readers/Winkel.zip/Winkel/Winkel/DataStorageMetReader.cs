﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Winkel
{
    public class DataStorageMetReader : DataStorage
    {
        public List<Customer> GetCustomers()
        {
            // ...
        }

        public void AddCustomer(Customer customer)
        {
            // ...
        }

        public void AddOrder(Order order)
        {
            // ...
        }

        
    }
}
